﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ZScore
{
    partial class ZScore
    {
        private static bool CSVread(string path, ref Column<string>[] Data)
        {
            const char DELIMETER_IN_DATA = ';';
            int count = 0;
            try
            {
                using (StreamReader readFile = new StreamReader(path))
                {
                    string line;
                    string[] row;

                    while ((line = readFile.ReadLine()) != null)
                    {
                        count++;
                        row = splitBy(line, DELIMETER_IN_DATA);
                        row = sReplace(row);
                        for (int i = 0; i < row.Length; i++)
                        {
                            if (checkTheCompleteness(row))
                                Data[i].AddData(row[i]);
                            //else Console.WriteLine("not-completed data");
                        }
                    }
                    readFile.Close();

                    Print(String.Format("RawSetSize/DataSetSize\t{0}/{1}\t({2:N2}% pominięto)", count, Data[0].GetNum(), (double)(count - Data[0].GetNum()) / count));

                    return true;
                }
            }
            catch (Exception e)
            {
                Print("Nieudany odczyt z pliku: ", e.Message);
            }

            return false;
        }

        private static Column<double>[] CSVreadAndParseToDouble(string path, EnumDataTypes dataType)
        {
            const char DELIMETER_IN_DATA = (char)9;
            int count = 0;

            Column<string>[] rawData = new Column<string>[(int)dataType];
            for (int i = 0; i < (int)dataType; i++)
                rawData[i] = new Column<string>();

            try
            {
                using (StreamReader readFile = new StreamReader(path))
                {
                    string line;
                    string[] row;

                    while ((line = readFile.ReadLine()) != null)
                    {
                        count++;
                        row = splitBy(line, DELIMETER_IN_DATA);
                        row = sReplace(row);
                        for (int i = 0; i < row.Length; i++)
                        {
                            if (checkTheCompleteness(row))
                                rawData[i].AddData(row[i]);
                            //else Console.WriteLine("not-completed data");
                        }
                    }
                    readFile.Close();

                    Print(String.Format("RawSetSize/DataSetSize\t{0}/{1}\t({2:N2}% pominięto)", count, rawData[0].GetNum(), (double)(count - rawData[0].GetNum()) / count));

                }
            }
            catch (Exception e)
            {
                Print("Nieudany odczyt z pliku: ", e.Message);
            }
            
            RemoveFromRecords(ref rawData, 0, 1);

            Column<double>[] discretizedData = new Column<double>[(int)dataType];
            for (int i = 0; i < (int)dataType; i++)
                discretizedData[i] = new Column<double>();

            for (int j = 0; j < rawData[0].GetNum(); j++)
            {
                for (int i = 0; i < (int)dataType; i++)
                {
                    double val;
                    try
                    {
                        val = double.Parse(rawData[i].Get(j));
                    }
                    catch
                    {
                        failParseInfo("value", i);
                        Console.WriteLine(rawData[i].Get(j));
                        val = -1;
                    }
                    discretizedData[i].AddData(val);
                }
            }

            return discretizedData;
        }


        private static string[] splitBy(string toParse, char delimiter)
        {
            char[] delimiterOption = new char[] { delimiter };
            return toParse.Split(delimiterOption, StringSplitOptions.None);
        }

        private static string[] sReplace(string[] toClear)
        {
            for (int i = 0; i < toClear.Length; i++)
            {
                toClear[i] = toClear[i].Replace("\"", "");
                toClear[i] = toClear[i].Replace(" ", "");
                if (toClear[i].Contains("0Balance"))
                    toClear[i] = toClear[i].Replace("0Balance", "Balance");
            }
            return toClear;
        }

        private static bool checkTheCompleteness(string[] toCheck)
        {
            foreach (string s in toCheck)
            {
                if (s == "")
                    return false;
            }
            return true;
        }
    }
}
