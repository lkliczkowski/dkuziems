﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ZScore
{
    partial class ZScore
    {
        private static bool CSVwrite(string path, Column<double>[] toWrite)
        {
            try
            {
                TextWriter writeFile = new StreamWriter(path);

                for (int j = 0; j < toWrite[1].GetNum(); j++)
                {
                    for (int i = 0; i < toWrite.Length; i++)
                    {

                        writeFile.Write("{0:N2};", toWrite[i].Get(j));
                        writeFile.Flush();
                    }
                    writeFile.WriteLine();
                }
                writeFile.Close();
                return true;
            }
            catch (Exception e)
            {
                Print("Nieudany zapis do pliku: ", e.Message);
            }

            return false;
        }
    }
}
